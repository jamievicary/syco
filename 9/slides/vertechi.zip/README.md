# README

If the folder is zipped, extract it to a location of your choice.

To access the slides, simply open the `index.html` file in your browser.

Press `F` to watch in full screen and use the arrows to navigate.